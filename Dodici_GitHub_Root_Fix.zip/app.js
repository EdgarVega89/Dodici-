
const STORAGE_KEY = "dodici-manager-console-web-v1"; // Keep same key so existing data migrates.
const APP_VERSION = 2;
const NAV = [
  ["Service", null],
  ["Dashboard","dashboard"],
  ["Guest Arrival","arrival"],
  ["Guest Profiles","profiles"],
  ["Visit History","history"],
  ["Operations",null],
  ["86 Center","stock"],
  ["Menu & Wine","menu"],
  ["What If?","whatif"],
  ["Admin",null],
  ["Settings","settings"]
];

let currentView = "dashboard";
let currentMenuCategory = "Pizzas";
let inventorySearch = "";
let inventoryCategory = "All";
let inventoryStatusFilter = "All";
let state = loadState();

function deepClone(v){ return JSON.parse(JSON.stringify(v)); }
function mergeState(saved){
  const defaults = deepClone(window.DODICI_DEFAULTS);
  const merged = {...defaults, ...saved};
  merged.settings = {...defaults.settings, ...(saved.settings||{})};
  merged.scenarios = Array.isArray(saved.scenarios) ? saved.scenarios : defaults.scenarios;
  merged.profiles = Array.isArray(saved.profiles) ? saved.profiles : [];
  merged.guests = Array.isArray(saved.guests) ? saved.guests.map(g=>({
    status:"active", rating:null, ratingNote:"", completedAt:null, ...g
  })) : [];
  const byId = new Map((saved.inventory||[]).map(i=>[i.id, i]));
  merged.inventory = defaults.inventory.map(def=>({...def, ...(byId.get(def.id)||{})}));
  // Preserve custom inventory items added by user.
  (saved.inventory||[]).forEach(i=>{ if(!merged.inventory.some(x=>x.id===i.id)) merged.inventory.push(i); });
  merged.appVersion = APP_VERSION;
  return merged;
}
function loadState(){
  try{
    const saved = localStorage.getItem(STORAGE_KEY);
    if(saved) return mergeState(JSON.parse(saved));
  }catch(e){}
  return mergeState({});
}
function saveState(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
function esc(v){ return String(v ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c])); }
function toast(msg){ const t=document.getElementById("toast"); t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1500); }
function navigate(view){ currentView=view;renderNav();render();window.scrollTo({top:0,behavior:"smooth"});history.replaceState(null,"","#"+view); }
function renderNav(){
  const desktop=document.getElementById("desktopNav"), mobile=document.getElementById("mobileNav");
  desktop.innerHTML=NAV.map(([label,view])=>view?`<button class="nav-btn ${currentView===view?"active":""}" data-view="${view}">${label}</button>`:`<div class="nav-group">${label}</div>`).join("");
  mobile.innerHTML=NAV.filter(x=>x[1]).map(([label,view])=>`<button class="nav-btn ${currentView===view?"active":""}" data-view="${view}">${label}</button>`).join("");
  document.querySelectorAll("[data-view]").forEach(b=>b.onclick=()=>navigate(b.dataset.view));
}
function header(kicker,title,right="Web App"){ return `<div class="page-top"><div><div class="kicker">${kicker}</div><h1>${title}</h1></div><div class="pill">${right}</div></div>`; }
function todayKey(d=new Date()){ return d.toISOString().slice(0,10); }
function isToday(iso){ return iso && iso.slice(0,10)===todayKey(); }
function inventoryStatus(i){
  if(i.qty===null || i.qty==="" || typeof i.qty==="undefined") return ["NOT SET","not-set"];
  const q=Number(i.qty);
  if(q<=0) return ["86","b-crit"];
  if(q<=Number(i.critical)) return ["CRITICAL","b-crit"];
  if(q<=Number(i.low)) return ["LOW","b-low"];
  return ["OK","b-ok"];
}
function renderAlerts(){
  const box=document.getElementById("alertBar");
  box.innerHTML=state.inventory.map(i=>{
    const [st]=inventoryStatus(i);
    if(st==="86") return `<div class="alert red">86: ${esc(i.name)}</div>`;
    if(st==="CRITICAL") return `<div class="alert red">CRITICAL: ${esc(i.name)} · ${i.qty} ${esc(i.unit||"")}</div>`;
    if(st==="LOW") return `<div class="alert orange">LOW: ${esc(i.name)} · ${i.qty} ${esc(i.unit||"")}</div>`;
    return "";
  }).join("");
}
function affectedItems(ingredientId){
  const result=[];
  Object.values(window.DODICI_MENU).flat().forEach(item=>{ if((item.ingredients||[]).includes(ingredientId)) result.push(item.name); });
  return result;
}
function activeGuests(){ return state.guests.filter(g=>(g.status||"active")==="active"); }
function completedGuests(){ return state.guests.filter(g=>g.status==="completed"); }
function avgRating(guests=completedGuests().filter(g=>g.rating)){
  if(!guests.length) return null;
  return guests.reduce((a,g)=>a+Number(g.rating),0)/guests.length;
}
function render(){
  renderAlerts();
  const view=document.getElementById("view");
  if(currentView==="dashboard") renderDashboard(view);
  if(currentView==="arrival") renderArrival(view);
  if(currentView==="profiles") renderProfiles(view);
  if(currentView==="history") renderHistory(view);
  if(currentView==="stock") renderStock(view);
  if(currentView==="menu") renderMenu(view);
  if(currentView==="whatif") renderWhatIf(view);
  if(currentView==="settings") renderSettings(view);
}
function guestBadges(g){
  const tags=[];
  if(g.firstVisit) tags.push(`<span class="badge b-first">FIRST VISIT</span>`);
  if(g.celebration&&g.celebration!=="No") tags.push(`<span class="badge b-vip">${esc(g.celebration).toUpperCase()}</span>`);
  if(g.allergy&&g.allergy!=="None") tags.push(`<span class="badge b-crit">ALLERGY</span>`);
  return tags.join("");
}
function renderDashboard(view){
  const todays=state.guests.filter(g=>isToday(g.createdAt));
  const first=todays.filter(g=>g.firstVisit).length;
  const celeb=todays.filter(g=>g.celebration&&g.celebration!=="No").length;
  const crit=state.inventory.filter(i=>["86","CRITICAL"].includes(inventoryStatus(i)[0])).length;
  const rating=avgRating(completedGuests().filter(g=>isToday(g.completedAt)));
  const guests=activeGuests().length?activeGuests().slice().reverse().map(g=>`
    <div class="item item-flex guest-card">
      <div><b>${esc(g.name)}</b> · Party ${g.party}<div class="muted tiny">Table ${esc(g.table||"TBD")} · ${esc(g.server||"Server TBD")} · ${esc(g.type)}</div><div class="row" style="margin-top:6px">${guestBadges(g)}</div></div>
      <div class="guest-actions"><button class="btn yellow small" data-complete="${esc(g.id)}">Complete Visit</button><button class="btn light small" data-remove="${esc(g.id)}">Remove</button></div>
    </div>`).join(""):`<div class="muted">No active guests right now.</div>`;
  view.innerHTML=header("Dodici Pizza & Wine","Manager Console","Persistent data")+`
  <div class="grid">
    <div class="card hero s8"><img src="/interior.jpeg"><div class="hero-copy"><div class="kicker" style="color:#ffe477">Hospitality starts before the table</div><h2>Know the guest. Prepare the team. Protect the experience.</h2><p>Guest intelligence, product knowledge and operational awareness in one place.</p></div></div>
    <div class="card s4"><h3>Today</h3><div class="list">
      <div class="item item-flex"><span>Active Guests</span><b>${activeGuests().length}</b></div>
      <div class="item item-flex"><span>First-Time Guests</span><b>${first}</b></div>
      <div class="item item-flex"><span>Celebrations</span><b>${celeb}</b></div>
      <div class="item item-flex"><span>Guest Satisfaction</span><b>${rating?rating.toFixed(1)+" ★":"—"}</b></div>
      <div class="item item-flex"><span>86 / Critical</span><b>${crit}</b></div>
      <div class="item item-flex"><span>Sales Goal</span><b>${esc(state.settings.salesGoal)}</b></div>
    </div></div>
    <div class="card s7"><div class="item-flex"><h3 style="margin:0">Active Guest Intelligence</h3><span class="badge b-first">${activeGuests().length} ACTIVE</span></div><div class="hr"></div><div class="list">${guests}</div></div>
    <div class="card s5"><h3>Quick Actions</h3><div class="list">
      <button class="item item-flex" data-go="arrival"><span>Seat a guest</span><b>→</b></button>
      <button class="item item-flex" data-go="stock"><span>Review 86 Center</span><b>→</b></button>
      <button class="item item-flex" data-go="history"><span>Visit History & Ratings</span><b>→</b></button>
      <button class="item item-flex" data-go="whatif"><span>Open What If?</span><b>→</b></button>
    </div></div>
  </div>`;
  view.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>navigate(b.dataset.go));
  view.querySelectorAll("[data-complete]").forEach(b=>b.onclick=()=>openCompleteVisit(b.dataset.complete));
  view.querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>removeGuest(b.dataset.remove));
}
function removeGuest(id){
  const g=state.guests.find(x=>String(x.id)===String(id)); if(!g)return;
  if(confirm(`Remove ${g.name}? Use this only for accidental/incorrect entries. Completed visits should use Complete Visit instead.`)){
    state.guests=state.guests.filter(x=>String(x.id)!==String(id));saveState();toast("Guest removed");render();
  }
}
function openCompleteVisit(id){
  const g=state.guests.find(x=>String(x.id)===String(id)); if(!g)return;
  let selected=5;
  const modal=document.getElementById("modal");modal.className="modal open";
  modal.innerHTML=`<div class="modal-box"><div class="kicker">COMPLETE VISIT</div><h3>${esc(g.name)} · Guest Satisfaction</h3><p class="muted">Record the guest's satisfaction before closing the visit.</p>
    <div id="stars" class="rating-stars">${[1,2,3,4,5].map(n=>`<button class="star-btn ${n<=selected?"selected":""}" data-star="${n}" aria-label="${n} stars">★</button>`).join("")}</div>
    <label>Optional Feedback / Note</label><textarea id="ratingNote" placeholder="What did the guest say? Anything to follow up on?"></textarea>
    <div class="row" style="margin-top:12px"><button id="saveRating" class="btn yellow">Save & Complete Visit</button><button id="cancelRating" class="btn light">Cancel</button></div></div>`;
  function paint(){ modal.querySelectorAll("[data-star]").forEach(s=>s.classList.toggle("selected",Number(s.dataset.star)<=selected)); }
  modal.querySelectorAll("[data-star]").forEach(s=>s.onclick=()=>{selected=Number(s.dataset.star);paint();});
  saveRating.onclick=()=>{g.status="completed";g.rating=selected;g.ratingNote=ratingNote.value.trim();g.completedAt=new Date().toISOString();saveState();modal.className="modal";modal.innerHTML="";toast("Visit completed");render();};
  cancelRating.onclick=()=>{modal.className="modal";modal.innerHTML="";};
}
function renderArrival(view){
  view.innerHTML=header("Service","Guest Arrival","Host intake")+`
  <div class="grid"><div class="card s7"><h3>Host Intake</h3><form id="arrivalForm"><div class="form-grid">
    <div><label>Guest / Reservation Name</label><input id="gName" required></div><div><label>Party Size</label><input id="gParty" type="number" min="1" value="2"></div>
    <div><label>Reservation / Walk-in</label><select id="gType"><option>Reservation</option><option>Walk-in</option></select></div><div><label>Table</label><input id="gTable"></div>
    <div><label>First Visit?</label><select id="gFirst"><option value="yes">Yes</option><option value="no">No</option></select></div><div><label>Celebrating?</label><select id="gCelebration"><option>No</option><option>Birthday</option><option>Anniversary</option><option>Date Night</option><option>Engagement</option><option>Graduation</option><option>Other</option></select></div>
    <div><label>Allergy / Dietary Concern</label><input id="gAllergy" placeholder="None / describe"></div><div><label>Assigned Server</label><input id="gServer"></div>
    </div><div class="hr"></div><button class="btn yellow">Create Handoff Card</button></form><div id="handoffResult" style="margin-top:14px"></div></div>
    <div class="card s5"><h3>First-Time Guest Standard</h3><div class="callout"><b>Host captures context before seating.</b> The server approaches the table already knowing whether it is a first visit, celebration or dietary concern.</div><div class="hr"></div>
      <div class="list"><div class="item"><b>1 · Welcome with context</b><div class="muted tiny">Do not make the guest repeat information.</div></div><div class="item"><b>2 · Tell the Dodici story</b><div class="muted tiny">Short and conversational.</div></div><div class="item"><b>3 · Guide the menu</b><div class="muted tiny">Explain key pizzas and products.</div></div><div class="item"><b>4 · Recommend wine</b><div class="muted tiny">Connect one pizza to one wine and explain why.</div></div></div></div></div>`;
  arrivalForm.onsubmit=e=>{
    e.preventDefault();
    const guest={id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),name:gName.value.trim(),party:Number(gParty.value)||1,type:gType.value,table:gTable.value.trim(),firstVisit:gFirst.value==="yes",celebration:gCelebration.value,allergy:gAllergy.value.trim()||"None",server:gServer.value.trim(),createdAt:new Date().toISOString(),status:"active",rating:null,ratingNote:"",completedAt:null};
    state.guests.push(guest);saveState();
    handoffResult.innerHTML=`<div class="handoff"><div class="item-flex"><div><div class="kicker">SERVER HANDOFF</div><div class="handoff-title">${esc(guest.name)} · Party ${guest.party}</div></div><div class="row">${guestBadges(guest)}</div></div><div class="muted tiny" style="margin-top:8px"><b>Table:</b> ${esc(guest.table||"TBD")} · <b>Server:</b> ${esc(guest.server||"TBD")} · <b>Arrival:</b> ${esc(guest.type)}<br><b>Allergy / concern:</b> ${esc(guest.allergy)}</div><div class="callout" style="margin-top:11px"><b>Next action:</b> ${guest.allergy!=="None"?"ALLERGY PRIORITY — notify manager/kitchen and verify ingredients.":guest.firstVisit?"Give the first-time Dodici introduction, guide the menu, and offer a wine pairing.":"Standard welcome with known guest context."}</div><div class="row" style="margin-top:11px"><button id="toDashboard" class="btn light">View Dashboard →</button><button id="newGuest" class="btn light">New Guest</button></div></div>`;
    toDashboard.onclick=()=>navigate("dashboard");newGuest.onclick=()=>renderArrival(view);toast("Guest saved");
  };
}
function renderProfiles(view){
  const profiles=state.profiles.length?state.profiles.map((p,i)=>`<div class="item item-flex"><div><b>${esc(p.name)}</b> <span class="badge ${p.status==="VIP"?"b-vip":"b-first"}">${esc(p.status).toUpperCase()}</span><div class="muted tiny">Usual: ${esc(p.order||"—")} · Wine: ${esc(p.wine||"—")} · Table: ${esc(p.table||"—")} · Birthday: ${esc(p.birthday||"—")}</div></div><button class="btn light small" data-delprofile="${i}">Delete</button></div>`).join(""):`<div class="muted">No guest profiles yet.</div>`;
  view.innerHTML=header("Guest Intelligence","Guest Profiles","Returning / VIP")+`<div class="grid"><div class="card s5"><h3>Create / Update Profile</h3><form id="profileForm"><div class="form-grid">
    <div><label>Name</label><input id="pName" required></div><div><label>Status</label><select id="pStatus"><option>Returning Guest</option><option>VIP</option></select></div><div><label>Birthday</label><input id="pBirthday" placeholder="MM/DD"></div><div><label>Preferred Table</label><input id="pTable"></div><div style="grid-column:1/-1"><label>Usual Order</label><input id="pOrder"></div><div style="grid-column:1/-1"><label>Wine Preference</label><input id="pWine"></div><div style="grid-column:1/-1"><label>Service Notes</label><textarea id="pNotes"></textarea></div></div><div class="hr"></div><button class="btn yellow">Save Profile</button></form></div><div class="card s7"><h3>Returning / VIP Guests</h3><div class="list">${profiles}</div></div></div>`;
  profileForm.onsubmit=e=>{e.preventDefault();state.profiles.push({name:pName.value.trim(),status:pStatus.value,birthday:pBirthday.value.trim(),table:pTable.value.trim(),order:pOrder.value.trim(),wine:pWine.value.trim(),notes:pNotes.value.trim()});saveState();toast("Profile saved");renderProfiles(view);};
  view.querySelectorAll("[data-delprofile]").forEach(b=>b.onclick=()=>{state.profiles.splice(Number(b.dataset.delprofile),1);saveState();renderProfiles(view)});
}
function renderHistory(view){
  const completed=completedGuests().slice().reverse();
  const avg=avgRating(completed);
  const cards=completed.length?completed.map(g=>`<div class="item"><div class="item-flex"><div><b>${esc(g.name)}</b> · Party ${g.party}<div class="muted tiny">${new Date(g.completedAt).toLocaleString()} · Table ${esc(g.table||"TBD")} · ${esc(g.server||"Server TBD")}</div></div><div class="history-rating">${"★".repeat(Number(g.rating||0))}${"☆".repeat(5-Number(g.rating||0))}</div></div>${g.ratingNote?`<div class="callout" style="margin-top:9px">${esc(g.ratingNote)}</div>`:""}</div>`).join(""):`<div class="muted">No completed visits yet.</div>`;
  view.innerHTML=header("Guest Intelligence","Visit History","Satisfaction")+`<div class="grid"><div class="card s4"><h3>Satisfaction Summary</h3><div class="metric">${avg?avg.toFixed(1)+" ★":"—"}</div><div class="muted tiny">${completed.length} completed visits rated</div></div><div class="card s8"><h3>Completed Visits</h3><div class="list">${cards}</div></div></div>`;
}
function renderStock(view){
  const categories=["All",...Array.from(new Set(state.inventory.map(i=>i.category||"Other"))).sort()];
  const filtered=state.inventory.filter(i=>{
    const [st]=inventoryStatus(i);
    const q=inventorySearch.trim().toLowerCase();
    return (!q || i.name.toLowerCase().includes(q)) &&
      (inventoryCategory==="All" || (i.category||"Other")===inventoryCategory) &&
      (inventoryStatusFilter==="All" || st===inventoryStatusFilter);
  });
  const rows=filtered.map(i=>{
    const idx=state.inventory.indexOf(i);const [st,cl]=inventoryStatus(i);const affected=affectedItems(i.id);
    return `<div class="item stock-grid"><div><b>${esc(i.name)}</b><div class="inventory-category">${esc(i.category||"Other")} · ${esc(i.unit||"count")}</div><div class="muted tiny">${affected.length?"Affects: "+affected.map(esc).join(", "):""}</div></div><input type="number" min="0" placeholder="—" value="${i.qty===null||typeof i.qty==="undefined"?"":i.qty}" data-qty="${idx}"><button class="btn light" data-sold="${idx}" ${i.qty===null||typeof i.qty==="undefined"?"disabled":""}>Sold 1</button><div class="status"><span class="badge ${cl}">${st}${st==="NOT SET"?"":" · "+i.qty}</span></div></div>`;
  }).join("");
  view.innerHTML=header("Operations","86 Center",`${state.inventory.length} tracked items`)+`<div class="grid"><div class="card s12"><div class="item-flex"><div><h3 style="margin:0">Full Inventory</h3><div class="muted tiny">Food, prep, produce, cheese, proteins, pantry and wine. New items remain NOT SET until a quantity is entered.</div></div><button id="addInventory" class="btn light">+ Add Item</button></div><div class="hr"></div>
    <div class="inventory-toolbar"><input id="invSearch" placeholder="Search inventory…" value="${esc(inventorySearch)}"><select id="invCategory">${categories.map(c=>`<option ${c===inventoryCategory?"selected":""}>${esc(c)}</option>`).join("")}</select><select id="invStatus"><option ${inventoryStatusFilter==="All"?"selected":""}>All</option><option ${inventoryStatusFilter==="NOT SET"?"selected":""}>NOT SET</option><option ${inventoryStatusFilter==="OK"?"selected":""}>OK</option><option ${inventoryStatusFilter==="LOW"?"selected":""}>LOW</option><option ${inventoryStatusFilter==="CRITICAL"?"selected":""}>CRITICAL</option><option ${inventoryStatusFilter==="86"?"selected":""}>86</option></select></div>
    <div class="list">${rows||'<div class="muted">No inventory items match this filter.</div>'}</div></div></div>`;
  invSearch.oninput=()=>{inventorySearch=invSearch.value;renderStock(view)};invCategory.onchange=()=>{inventoryCategory=invCategory.value;renderStock(view)};invStatus.onchange=()=>{inventoryStatusFilter=invStatus.value;renderStock(view)};
  view.querySelectorAll("[data-qty]").forEach(input=>input.onchange=()=>{const i=state.inventory[Number(input.dataset.qty)],prev=i.qty;i.qty=input.value===""?null:Math.max(0,Number(input.value)||0);saveState();if(prev!==0&&i.qty===0)show86(i);else renderStock(view);});
  view.querySelectorAll("[data-sold]").forEach(btn=>btn.onclick=()=>{const i=state.inventory[Number(btn.dataset.sold)];if(i.qty===null)return;const prev=i.qty;i.qty=Math.max(0,Number(i.qty)-1);saveState();if(prev>0&&i.qty===0)show86(i);else renderStock(view);});
  addInventory.onclick=()=>{const name=prompt("Item name");if(!name)return;state.inventory.push({id:"custom_"+Date.now(),name,category:"Other",unit:"count",qty:null,low:3,critical:1});saveState();renderStock(view);};
}
function show86(item){
  const affected=affectedItems(item.id),modal=document.getElementById("modal");modal.className="modal open";modal.innerHTML=`<div class="modal-box"><div class="kicker">NEW 86 ALERT</div><h3>${esc(item.name)} is now 86</h3><p class="muted">${affected.length?"Affected menu items: "+affected.map(esc).join(", "):"No menu dependencies are mapped yet."}</p><button id="ack86" class="btn yellow">I UNDERSTAND</button></div>`;ack86.onclick=()=>{modal.className="modal";modal.innerHTML="";renderAlerts();render();};
}
function wineKey(w){return "wine_"+(w[0]+"_"+w[1]).toLowerCase().replace(/[^a-z0-9]+/g,"_").replace(/^_|_$/g,"");}
function renderMenu(view){
  const categories=Object.keys(window.DODICI_MENU);
  const cards=window.DODICI_MENU[currentMenuCategory].map(m=>{const blocked=(m.ingredients||[]).some(id=>{const x=state.inventory.find(i=>i.id===id);return x&&x.qty!==null&&Number(x.qty)<=0});const low=(m.ingredients||[]).some(id=>{const x=state.inventory.find(i=>i.id===id);return x&&x.qty!==null&&Number(x.qty)>0&&Number(x.qty)<=Number(x.low)});return `<div class="menu-item"><b><span>${esc(m.name)}</span><span>${esc(m.price)}</span></b><p>${esc(m.desc)}</p>${blocked?'<div class="badge b-crit" style="margin-top:7px">86 AFFECTED</div>':low?'<div class="badge b-low" style="margin-top:7px">LOW STOCK RISK</div>':""}</div>`}).join("");
  function wineCard(w){const x=state.inventory.find(i=>i.id===wineKey(w)),st=x?inventoryStatus(x)[0]:"NOT SET";return `<div class="wine"><b>${esc(w[0])}</b><span>${esc(w[3])}</span><small>${esc(w[1])} · ${esc(w[2])}</small>${st==="86"?'<div class="badge b-crit">86</div>':st==="LOW"||st==="CRITICAL"?'<div class="badge b-low">'+st+'</div>':""}</div>`}
  view.innerHTML=header("Product Knowledge","Menu & Wine","Guest guidance")+`<div class="grid"><div class="card s8"><div class="item-flex"><div><h3 style="margin:0">Menu Knowledge</h3><div class="muted tiny">Linked to 86 Center.</div></div><button id="foodScan" class="btn light">Original Menu</button></div><div class="hr"></div><div class="menu-tabs">${categories.map(c=>`<button class="tab-btn ${c===currentMenuCategory?"active":""}" data-cat="${esc(c)}">${esc(c)}</button>`).join("")}</div><div class="menu-grid">${cards}</div></div>
    <div class="card s4"><h3>First-Visit Product Story</h3><div class="list"><div class="item"><b>Oven</b><div class="muted tiny">${esc(state.settings.oven)}</div></div><div class="item"><b>Dough</b><div class="muted tiny">${esc(state.settings.dough)}</div></div><div class="item"><b>Pepperoni</b><div class="muted tiny">${esc(state.settings.pepperoni)}</div></div><div class="item"><b>Mozzarella</b><div class="muted tiny">${esc(state.settings.mozzarella)}</div></div></div></div>
    <div class="card s6"><h3>Wine · By the Glass</h3><div class="wine-grid">${window.DODICI_WINES_GLASS.map(wineCard).join("")}</div></div><div class="card s6"><div class="item-flex"><h3 style="margin:0">Wine · By the Bottle</h3><button id="wineScan" class="btn light">Original Wine Menu</button></div><div class="hr"></div><div class="wine-grid">${window.DODICI_WINES_BOTTLE.map(wineCard).join("")}</div></div></div>`;
  view.querySelectorAll("[data-cat]").forEach(b=>b.onclick=()=>{currentMenuCategory=b.dataset.cat;renderMenu(view)});foodScan.onclick=()=>showImage("/food-menu.jpeg","Original Food Menu");wineScan.onclick=()=>showImage("/wine-menu.jpeg","Original Wine Menu");
}
function showImage(src,title){const modal=document.getElementById("modal");modal.className="modal open";modal.innerHTML=`<div class="modal-box" style="max-width:850px;max-height:90vh;overflow:auto"><div class="item-flex"><h3>${esc(title)}</h3><button id="closeModal" class="btn light">Close</button></div><img class="scan" src="${src}"></div>`;closeModal.onclick=()=>{modal.className="modal";modal.innerHTML=""};}
function renderWhatIf(view){view.innerHTML=header("Playbook","What If?","Editable standards")+`<div class="grid"><div class="card s12"><div class="list">${state.scenarios.map(s=>`<details><summary>${esc(s.title)}</summary><p class="muted">${esc(s.body)}</p></details>`).join("")}</div></div></div>`;}
function renderSettings(view){
  view.innerHTML=header("Admin","Settings","Editable")+`<div class="grid"><div class="card s6"><h3>Product Story</h3><form id="storyForm"><label>Oven</label><textarea id="sOven">${esc(state.settings.oven)}</textarea><label>Dough</label><textarea id="sDough">${esc(state.settings.dough)}</textarea><label>Pepperoni</label><textarea id="sPepperoni">${esc(state.settings.pepperoni)}</textarea><label>Mozzarella</label><textarea id="sMozzarella">${esc(state.settings.mozzarella)}</textarea><label>Wine Guidance</label><textarea id="sWine">${esc(state.settings.wine)}</textarea><button class="btn yellow">Save Story</button></form></div>
    <div class="card s6"><h3>Operational Targets</h3><form id="targetsForm"><label>Daily Sales Goal</label><input id="sSales" value="${esc(state.settings.salesGoal)}"><label>Labor % Target</label><input id="sLabor" value="${esc(state.settings.laborTarget)}"><label>Food Cost % Target</label><input id="sFood" value="${esc(state.settings.foodCostTarget)}"><label>Ticket Time Target</label><input id="sTicket" value="${esc(state.settings.ticketTarget)}"><button class="btn yellow">Save Targets</button></form><div class="hr"></div><button id="resetApp" class="btn danger">Reset Local Data</button></div></div>`;
  storyForm.onsubmit=e=>{e.preventDefault();Object.assign(state.settings,{oven:sOven.value,dough:sDough.value,pepperoni:sPepperoni.value,mozzarella:sMozzarella.value,wine:sWine.value});saveState();toast("Story saved")};
  targetsForm.onsubmit=e=>{e.preventDefault();Object.assign(state.settings,{salesGoal:sSales.value||"TBD",laborTarget:sLabor.value||"TBD",foodCostTarget:sFood.value||"TBD",ticketTarget:sTicket.value||"TBD"});saveState();toast("Targets saved")};
  resetApp.onclick=()=>{if(confirm("Reset all Dodici Manager Console data stored on this device?")){state=mergeState({});saveState();toast("Data reset");navigate("dashboard")}};
}
const initial=(location.hash||"#dashboard").slice(1);if(NAV.some(x=>x[1]===initial))currentView=initial;renderNav();render();saveState();
if("serviceWorker" in navigator){window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));}
